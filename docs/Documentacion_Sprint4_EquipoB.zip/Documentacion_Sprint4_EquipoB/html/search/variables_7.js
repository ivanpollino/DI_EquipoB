var searchData=
[
  ['sepuedeapuntar_0',['sePuedeApuntar',['../class_presentacion_1_1_formularios_1_1_actividades_apuntado.html#a3f8ad8111504520ae676dfca8fb524d5',1,'Presentacion::Formularios::ActividadesApuntado']]]
];
