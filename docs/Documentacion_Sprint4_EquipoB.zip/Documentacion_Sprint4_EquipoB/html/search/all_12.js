var searchData=
[
  ['telefono_0',['Telefono',['../class_negocio_1_1_entities_d_t_o_1_1_usuario_d_t_o.html#ae0bdae5a684f512a32228c03a2b91c00',1,'Negocio.EntitiesDTO.UsuarioDTO.Telefono'],['../class_datos_1_1_infrastructure_1_1_usuario.html#a2432589a6dcb080a0f493b67f0b17136',1,'Datos.Infrastructure.Usuario.Telefono']]],
  ['the_20strong_20homepage_20strong_1',['This is the &lt;strong&gt;HOMEPAGE&lt;/strong&gt;.',['../md__datos_2index.html',1,'']]],
  ['this_20is_20the_20strong_20homepage_20strong_2',['This is the &lt;strong&gt;HOMEPAGE&lt;/strong&gt;.',['../md__datos_2index.html',1,'']]],
  ['toc_3',['toc',['../md__datos_2articles_2toc.html',1,'']]],
  ['toc_2emd_4',['toc.md',['../toc_8md.html',1,'']]]
];
