var searchData=
[
  ['id_5factividad_0',['Id_Actividad',['../class_negocio_1_1_entities_d_t_o_1_1_actividad_d_t_o.html#af173dc8e306b146a347469d521e866b9',1,'Negocio.EntitiesDTO.ActividadDTO.Id_Actividad'],['../class_negocio_1_1_entities_d_t_o_1_1_usuario_actividad_d_t_o.html#a16c8bb55cf194d9a6ef7f5bbd42aa935',1,'Negocio.EntitiesDTO.UsuarioActividadDTO.Id_Actividad'],['../class_datos_1_1_infrastructure_1_1_actividad.html#a3b247566bf0797b3d9a348ad80dbfe29',1,'Datos.Infrastructure.Actividad.Id_Actividad'],['../class_datos_1_1_infrastructure_1_1_usuario___actividad.html#a44217ac041599975a6fd0a92c2cc6324',1,'Datos.Infrastructure.Usuario_Actividad.Id_Actividad']]],
  ['index_2emd_1',['index.md',['../api_2index_8md.html',1,'(Global Namespace)'],['../index_8md.html',1,'(Global Namespace)']]],
  ['intro_2emd_2',['intro.md',['../intro_8md.html',1,'']]],
  ['introductions_20here_3',['Add your introductions here!',['../md__datos_2articles_2intro.html',1,'']]],
  ['is_20the_20strong_20homepage_20strong_4',['This is the &lt;strong&gt;HOMEPAGE&lt;/strong&gt;.',['../md__datos_2index.html',1,'']]]
];
