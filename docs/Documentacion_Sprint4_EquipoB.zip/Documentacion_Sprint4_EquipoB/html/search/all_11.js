var searchData=
[
  ['sacaractividad_0',['sacarActividad',['../class_datos_1_1_repositorys_1_1_actividad_repository.html#a065eb4e042b8700712b3d4093eeb2366',1,'Datos::Repositorys::ActividadRepository']]],
  ['sacarnombreapellidosdeusuario_1',['sacarNombreApellidosDeUsuario',['../class_negocio_1_1_managment_1_1_usuario_managment.html#a952b8997cc1be8c1b2ee2854497ac363',1,'Negocio::Managment::UsuarioManagment']]],
  ['sacarnombrepordni_2',['sacarNombrePorDNI',['../class_datos_1_1_repositorys_1_1_usuario_repository.html#a13f000312563b5b60ef71b522c7a79f7',1,'Datos::Repositorys::UsuarioRepository']]],
  ['sepuedeapuntar_3',['sePuedeApuntar',['../class_presentacion_1_1_formularios_1_1_actividades_apuntado.html#a3f8ad8111504520ae676dfca8fb524d5',1,'Presentacion::Formularios::ActividadesApuntado']]],
  ['settings_2edesigner_2ecs_4',['Settings.Designer.cs',['../_settings_8_designer_8cs.html',1,'']]],
  ['start_20notes_3a_5',['Quick Start Notes:',['../md__datos_2index.html#autotoc_md3',1,'']]],
  ['strong_6',['This is the &lt;strong&gt;HOMEPAGE&lt;/strong&gt;.',['../md__datos_2index.html',1,'']]],
  ['strong_20homepage_20strong_7',['This is the &lt;strong&gt;HOMEPAGE&lt;/strong&gt;.',['../md__datos_2index.html',1,'']]]
];
