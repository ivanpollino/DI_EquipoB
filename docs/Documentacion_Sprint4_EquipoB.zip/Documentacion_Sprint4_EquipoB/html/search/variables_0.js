var searchData=
[
  ['actividadaux_0',['actividadAux',['../class_presentacion_1_1_formularios_1_1_ver_informacion_actividad.html#abafdce69f8e2b9fd4889b21267f747d2',1,'Presentacion::Formularios::VerInformacionActividad']]],
  ['actividaddto_1',['actividadDto',['../class_presentacion_1_1_componentes_personalizados_1_1_actividad_pesta_xC3_xB1a.html#ab74bc88c3c10b597ab20a29bf06e290c',1,'Presentacion.ComponentesPersonalizados.ActividadPestaña.actividadDto'],['../class_presentacion_1_1_componentes_personalizados_1_1_actividad_usuario.html#ad168ed4df41e812a69480894c7eada47',1,'Presentacion.ComponentesPersonalizados.ActividadUsuario.actividadDto']]]
];
