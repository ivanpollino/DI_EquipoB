var searchData=
[
  ['obteneractividades_0',['ObtenerActividades',['../class_negocio_1_1_managment_1_1_actividad_managment.html#aed1b24ad8923f92ad4b28222ed8f31be',1,'Negocio::Managment::ActividadManagment']]],
  ['obteneractividadesapuntado_1',['ObtenerActividadesApuntado',['../class_negocio_1_1_managment_1_1_usuario_actividad_managment.html#a29a1a52010081d08e915c2d1027e2293',1,'Negocio::Managment::UsuarioActividadManagment']]],
  ['obteneractividadporid_2',['ObtenerActividadPorId',['../class_negocio_1_1_managment_1_1_actividad_managment.html#ac2ce242dbf44766e05aed7c8ea2bc341',1,'Negocio.Managment.ActividadManagment.ObtenerActividadPorId()'],['../class_datos_1_1_repositorys_1_1_actividad_repository.html#a12b99924eda6ca7343d5d0ff3ff37404',1,'Datos.Repositorys.ActividadRepository.ObtenerActividadPorId()']]],
  ['obteneradministradores_3',['obtenerAdministradores',['../class_datos_1_1_repositorys_1_1_usuario_repository.html#a74cd05420c71aeb48daf34dea98a3282',1,'Datos::Repositorys::UsuarioRepository']]],
  ['obtenerformulariopadre_4',['ObtenerFormularioPadre',['../class_presentacion_1_1_formularios_1_1_actividades_apuntado.html#a42fb04a6978536bc049940eb006446d0',1,'Presentacion::Formularios::ActividadesApuntado']]],
  ['obtenermonitores_5',['ObtenerMonitores',['../class_datos_1_1_repositorys_1_1_monitor_repository.html#ab6ecb065db94d0453516e4fa27f6023c',1,'Datos::Repositorys::MonitorRepository']]],
  ['obtenermonitorpordni_6',['ObtenerMonitorPorDni',['../class_datos_1_1_repositorys_1_1_actividad_repository.html#a6d7d4955ef555dbe68cb6eda09f52245',1,'Datos.Repositorys.ActividadRepository.ObtenerMonitorPorDni()'],['../class_datos_1_1_repositorys_1_1_monitor_repository.html#a31a9df747d739c903bbd92e4ea5fd112',1,'Datos.Repositorys.MonitorRepository.ObtenerMonitorPorDni()']]],
  ['obtenernuevoidactividad_7',['ObtenerNuevoIdActividad',['../class_datos_1_1_repositorys_1_1_actividad_repository.html#a9498f1cba85a1dac43b1d94c4de760fa',1,'Datos::Repositorys::ActividadRepository']]],
  ['obtenerusuarios_8',['ObtenerUsuarios',['../class_datos_1_1_repositorys_1_1_usuario_repository.html#a227ab1248f06f9f35f42a097682d641f',1,'Datos::Repositorys::UsuarioRepository']]],
  ['obtenerusuariosmonitores_9',['ObtenerUsuariosMonitores',['../class_negocio_1_1_managment_1_1_monitor_managment.html#aa7dd690d7746455edca91c1c7cd27ae0',1,'Negocio::Managment::MonitorManagment']]],
  ['obtenerusuariosnormal_10',['obtenerUsuariosNormal',['../class_datos_1_1_repositorys_1_1_usuario_repository.html#a1195f827f95dfcd31e897d4c8e11d954',1,'Datos::Repositorys::UsuarioRepository']]],
  ['obtenervaloracion_11',['ObtenerValoracion',['../class_negocio_1_1_managment_1_1_usuario_actividad_managment.html#a11c4329168e2422ba32bb072befc98ac',1,'Negocio.Managment.UsuarioActividadManagment.ObtenerValoracion()'],['../class_datos_1_1_repositorys_1_1_usuario_actividad_repository.html#af8cf1821e793d609d504d5ba0c4dd970',1,'Datos.Repositorys.UsuarioActividadRepository.ObtenerValoracion()']]],
  ['onmodelcreating_12',['OnModelCreating',['../class_datos_1_1_infrastructure_1_1equipob_entities.html#a93fa192ac6160ec4d42d7d7372fa03fe',1,'Datos::Infrastructure::equipobEntities']]]
];
