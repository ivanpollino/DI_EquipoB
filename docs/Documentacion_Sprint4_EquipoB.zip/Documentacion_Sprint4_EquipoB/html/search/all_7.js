var searchData=
[
  ['guardaractividad_0',['GuardarActividad',['../class_datos_1_1_repositorys_1_1_actividad_repository.html#abcc34f6bfe077d3956457f3f4b557026',1,'Datos.Repositorys.ActividadRepository.GuardarActividad()'],['../class_datos_1_1_repositorys_1_1_usuario_actividad_repository.html#a432dff79dbaeb22984001c4542260225',1,'Datos.Repositorys.UsuarioActividadRepository.GuardarActividad(Usuario_Actividad actividad)']]],
  ['guardaroactualizarvaloracion_1',['GuardarOActualizarValoracion',['../class_datos_1_1_repositorys_1_1_usuario_actividad_repository.html#a68d8808f837402544602e403d6b2f69b',1,'Datos::Repositorys::UsuarioActividadRepository']]]
];
