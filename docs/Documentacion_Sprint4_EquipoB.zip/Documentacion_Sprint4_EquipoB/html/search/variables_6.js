var searchData=
[
  ['registrocorrecto_0',['registroCorrecto',['../class_presentacion_1_1_registro.html#a7289f1b9397d899fd4d4de673636fb90',1,'Presentacion.Registro.registroCorrecto'],['../class_presentacion_1_1_registro_monitor.html#a5551792b1f123ad7e785d762f10131c4',1,'Presentacion.RegistroMonitor.registroCorrecto']]]
];
