var searchData=
[
  ['class1_0',['Class1',['../class_datos_1_1_class1.html',1,'Datos.Class1'],['../class_negocio_1_1_class1.html',1,'Negocio.Class1']]]
];
