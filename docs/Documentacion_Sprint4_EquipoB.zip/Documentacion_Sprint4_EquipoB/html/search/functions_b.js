var searchData=
[
  ['usuario_5fnormal_0',['Usuario_Normal',['../class_datos_1_1_infrastructure_1_1_usuario___normal.html#a7adea74bc35981a2af68208990d56c6c',1,'Datos::Infrastructure::Usuario_Normal']]],
  ['usuarioactividaddto_1',['UsuarioActividadDTO',['../class_negocio_1_1_entities_d_t_o_1_1_usuario_actividad_d_t_o.html#abfa39111d46bab4b2663879dcdb0a18d',1,'Negocio.EntitiesDTO.UsuarioActividadDTO.UsuarioActividadDTO(string dni, int id_actividad)'],['../class_negocio_1_1_entities_d_t_o_1_1_usuario_actividad_d_t_o.html#a0e5f1f125af55fa0d4b593b006498541',1,'Negocio.EntitiesDTO.UsuarioActividadDTO.UsuarioActividadDTO()']]],
  ['usuariodto_2',['UsuarioDTO',['../class_negocio_1_1_entities_d_t_o_1_1_usuario_d_t_o.html#ae7068fe5078b4aef962d858b22331d67',1,'Negocio.EntitiesDTO.UsuarioDTO.UsuarioDTO(string dNI, string nombre, string apellidos, int? telefono, string direccion, string cuenta_Corriente, string email, string passwd)'],['../class_negocio_1_1_entities_d_t_o_1_1_usuario_d_t_o.html#a19954eb6c9d1f10146c04be78dd36755',1,'Negocio.EntitiesDTO.UsuarioDTO.UsuarioDTO()']]]
];
