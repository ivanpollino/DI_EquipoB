var searchData=
[
  ['email_0',['Email',['../class_negocio_1_1_entities_d_t_o_1_1_usuario_d_t_o.html#a53ca0d96f3df91d4132e173e4c27f8b6',1,'Negocio.EntitiesDTO.UsuarioDTO.Email'],['../class_datos_1_1_infrastructure_1_1_usuario.html#af71530d1e68f05bdb467f54a204a0400',1,'Datos.Infrastructure.Usuario.Email']]]
];
