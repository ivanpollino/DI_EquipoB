var searchData=
[
  ['valoracion_0',['Valoracion',['../class_negocio_1_1_entities_d_t_o_1_1_usuario_actividad_d_t_o.html#a3bf135cf135d4acfe066ba04b6a83f15',1,'Negocio.EntitiesDTO.UsuarioActividadDTO.Valoracion'],['../class_datos_1_1_infrastructure_1_1_usuario___actividad.html#aeabefe2963f3beadf73893f75d94d871',1,'Datos.Infrastructure.Usuario_Actividad.Valoracion']]]
];
