var searchData=
[
  ['add_20your_20introductions_20here_0',['Add your introductions here!',['../md__datos_2articles_2intro.html',1,'']]]
];
