var searchData=
[
  ['quick_20start_20notes_3a_0',['Quick Start Notes:',['../md__datos_2index.html#autotoc_md3',1,'']]]
];
