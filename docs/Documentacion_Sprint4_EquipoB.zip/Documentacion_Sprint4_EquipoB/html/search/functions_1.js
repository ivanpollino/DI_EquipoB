var searchData=
[
  ['bajaactividad_0',['bajaActividad',['../class_negocio_1_1_managment_1_1_actividad_managment.html#a70429f98e4593a7891714b9468a76440',1,'Negocio.Managment.ActividadManagment.bajaActividad()'],['../class_datos_1_1_repositorys_1_1_actividad_repository.html#a37a4fe8bbdbd1d001e7764b2031d6d76',1,'Datos.Repositorys.ActividadRepository.bajaActividad()']]],
  ['botonswitch_1',['BotonSwitch',['../class_presentacion_1_1_componentes_personalizados_1_1_boton_switch.html#a44655b28e70527c0aa055624f2ef5e88',1,'Presentacion::ComponentesPersonalizados::BotonSwitch']]],
  ['botonswitch_5fclick_2',['BotonSwitch_Click',['../class_presentacion_1_1_componentes_personalizados_1_1_boton_switch.html#a789980db5b7707a242cd5f56694a69e8',1,'Presentacion::ComponentesPersonalizados::BotonSwitch']]]
];
