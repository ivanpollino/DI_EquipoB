var searchData=
[
  ['estado_0',['estado',['../class_presentacion_1_1_componentes_personalizados_1_1_boton_switch.html#a6a642207fb9da42c4c436326fab0da22',1,'Presentacion::ComponentesPersonalizados::BotonSwitch']]]
];
