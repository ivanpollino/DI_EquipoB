var searchData=
[
  ['negocio_0',['Negocio',['../namespace_negocio.html',1,'']]],
  ['negocio_3a_3aentitiesdto_1',['EntitiesDTO',['../namespace_negocio_1_1_entities_d_t_o.html',1,'Negocio']]],
  ['negocio_3a_3amanagment_2',['Managment',['../namespace_negocio_1_1_managment.html',1,'Negocio']]],
  ['nombre_3',['Nombre',['../class_negocio_1_1_entities_d_t_o_1_1_actividad_d_t_o.html#ac8fbfdae27e6547effe66158c51ae997',1,'Negocio.EntitiesDTO.ActividadDTO.Nombre'],['../class_negocio_1_1_entities_d_t_o_1_1_usuario_d_t_o.html#a2e3a354ff76e383b50bab27c9b1c5db3',1,'Negocio.EntitiesDTO.UsuarioDTO.Nombre'],['../class_datos_1_1_infrastructure_1_1_actividad.html#a94e25ec0e9e91db9a0707e1bcf848489',1,'Datos.Infrastructure.Actividad.Nombre'],['../class_datos_1_1_infrastructure_1_1_usuario.html#af4859eb259e0e4721fb92935e7213ae5',1,'Datos.Infrastructure.Usuario.Nombre']]],
  ['nombrecompleto_4',['NombreCompleto',['../class_negocio_1_1_entities_d_t_o_1_1_usuario_d_t_o.html#a4f299d74cd84e396c146598835f2a348',1,'Negocio::EntitiesDTO::UsuarioDTO']]],
  ['nombremonitor_5',['nombreMonitor',['../class_presentacion_1_1_formularios_1_1_ver_informacion_actividad.html#a6326f22a575d7a1f9b819dacff84470a',1,'Presentacion::Formularios::VerInformacionActividad']]],
  ['notes_3a_6',['Quick Start Notes:',['../md__datos_2index.html#autotoc_md3',1,'']]]
];
