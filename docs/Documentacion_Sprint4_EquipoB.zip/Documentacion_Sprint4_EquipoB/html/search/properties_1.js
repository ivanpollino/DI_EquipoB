var searchData=
[
  ['cuenta_5fcorriente_0',['Cuenta_Corriente',['../class_negocio_1_1_entities_d_t_o_1_1_usuario_d_t_o.html#a2a17d41b3aff89fb32d5ef1948065381',1,'Negocio.EntitiesDTO.UsuarioDTO.Cuenta_Corriente'],['../class_datos_1_1_infrastructure_1_1_usuario.html#a46f7aa306c245f2f23af8d77af55a254',1,'Datos.Infrastructure.Usuario.Cuenta_Corriente']]]
];
