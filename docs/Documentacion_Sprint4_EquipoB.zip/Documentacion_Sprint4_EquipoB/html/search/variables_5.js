var searchData=
[
  ['nombremonitor_0',['nombreMonitor',['../class_presentacion_1_1_formularios_1_1_ver_informacion_actividad.html#a6326f22a575d7a1f9b819dacff84470a',1,'Presentacion::Formularios::VerInformacionActividad']]]
];
