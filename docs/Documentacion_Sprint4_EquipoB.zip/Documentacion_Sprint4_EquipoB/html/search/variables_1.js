var searchData=
[
  ['contenedoractividades_0',['contenedorActividades',['../class_presentacion_1_1_formularios_1_1_actividades_apuntado.html#a6e8f8aaf5cf284d318fb59234ef447ac',1,'Presentacion.Formularios.ActividadesApuntado.contenedorActividades'],['../class_presentacion_1_1_listado_actividades.html#a21fa88ddf1959c972704a2f6bd7c3021',1,'Presentacion.ListadoActividades.contenedorActividades']]]
];
