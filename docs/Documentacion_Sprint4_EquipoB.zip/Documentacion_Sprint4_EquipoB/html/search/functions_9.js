var searchData=
[
  ['registraractividad_0',['RegistrarActividad',['../class_negocio_1_1_managment_1_1_actividad_managment.html#a3d98352e8a6396d0e23ad9e58e6900bd',1,'Negocio.Managment.ActividadManagment.RegistrarActividad()'],['../class_presentacion_1_1_registrar_actividad.html#ad022f78a47c59cda83e14326139e7552',1,'Presentacion.RegistrarActividad.RegistrarActividad()']]],
  ['registrarusuarioactividad_1',['RegistrarUsuarioActividad',['../class_negocio_1_1_managment_1_1_usuario_actividad_managment.html#a74db2b21882d84476fc3269ac2dd4455',1,'Negocio::Managment::UsuarioActividadManagment']]],
  ['registro_2',['Registro',['../class_presentacion_1_1_registro.html#af4daf9f33811eb12505d68d646e0b030',1,'Presentacion::Registro']]],
  ['registromonitor_3',['RegistroMonitor',['../class_presentacion_1_1_registro_monitor.html#ac4861766e7becbc669994d467f0cef1a',1,'Presentacion::RegistroMonitor']]]
];
