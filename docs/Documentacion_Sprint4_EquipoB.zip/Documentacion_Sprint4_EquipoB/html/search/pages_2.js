var searchData=
[
  ['introductions_20here_0',['Add your introductions here!',['../md__datos_2articles_2intro.html',1,'']]],
  ['is_20the_20strong_20homepage_20strong_1',['This is the &lt;strong&gt;HOMEPAGE&lt;/strong&gt;.',['../md__datos_2index.html',1,'']]]
];
