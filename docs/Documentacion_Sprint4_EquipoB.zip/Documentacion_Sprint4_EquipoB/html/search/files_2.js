var searchData=
[
  ['botonswitch_2ecs_0',['BotonSwitch.cs',['../_boton_switch_8cs.html',1,'']]],
  ['botonswitch_2edesigner_2ecs_1',['BotonSwitch.Designer.cs',['../_boton_switch_8_designer_8cs.html',1,'']]]
];
