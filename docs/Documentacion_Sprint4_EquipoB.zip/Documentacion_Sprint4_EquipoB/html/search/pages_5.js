var searchData=
[
  ['the_20strong_20homepage_20strong_0',['This is the &lt;strong&gt;HOMEPAGE&lt;/strong&gt;.',['../md__datos_2index.html',1,'']]],
  ['this_20is_20the_20strong_20homepage_20strong_1',['This is the &lt;strong&gt;HOMEPAGE&lt;/strong&gt;.',['../md__datos_2index.html',1,'']]],
  ['toc_2',['toc',['../md__datos_2articles_2toc.html',1,'']]]
];
