var searchData=
[
  ['registraractividad_0',['RegistrarActividad',['../class_presentacion_1_1_registrar_actividad.html',1,'Presentacion']]],
  ['registro_1',['Registro',['../class_presentacion_1_1_registro.html',1,'Presentacion']]],
  ['registromonitor_2',['RegistroMonitor',['../class_presentacion_1_1_registro_monitor.html',1,'Presentacion']]]
];
