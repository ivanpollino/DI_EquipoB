var searchData=
[
  ['usuario_0',['usuario',['../class_presentacion_1_1_componentes_personalizados_1_1_actividad_usuario.html#a477ad12c2ed3e0a48200823fab7fb1e7',1,'Presentacion.ComponentesPersonalizados.ActividadUsuario.usuario'],['../class_presentacion_1_1_formularios_1_1_ver_informacion_actividad.html#ac7432cc1282c40d223312063a875a3da',1,'Presentacion.Formularios.VerInformacionActividad.usuario']]]
];
