var searchData=
[
  ['here_0',['Add your introductions here!',['../md__datos_2articles_2intro.html',1,'']]],
  ['homepage_20strong_1',['This is the &lt;strong&gt;HOMEPAGE&lt;/strong&gt;.',['../md__datos_2index.html',1,'']]]
];
